import { PrismaClient } from '@prisma/client';
import bcrypt from 'bcryptjs';

const prisma = new PrismaClient();

async function main() {
  console.log('Setting up your CRM...');
  // Skip if already seeded
  const existing = await prisma.company.findUnique({ where: { slug: "claflin-construction" } });
  if (existing) { console.log("Already seeded, skipping."); return; }

  // Create company
  const company = await prisma.company.create({
    data: {
      name: 'Claflin Construction',
      slug: 'claflin-construction',
      email: 'info@claflinconstruction.net',
      phone: '1',
      address: '123 Main St',
      city: '1',
      state: 'ST',
      zip: '00000',
      primaryColor: '#f97316',
      secondaryColor: '#1e3a5f',
      website: 'https://claflin-construction.com',
      enabledFeatures: [
            "contacts",
            "jobs",
            "quotes",
            "invoices",
            "scheduling",
            "team",
            "dashboard",
            "projects",
            "rfis",
            "change_orders",
            "punch_lists",
            "daily_logs",
            "inspections",
            "bid_management",
            "takeoff_tools",
            "selections",
            "drag_drop_calendar",
            "recurring_jobs",
            "route_optimization",
            "online_booking",
            "service_dispatch",
            "service_agreements",
            "warranties",
            "pricebook",
            "time_tracking",
            "gps_tracking",
            "photo_capture",
            "equipment_tracking",
            "fleet",
            "online_payments",
            "expense_tracking",
            "job_costing",
            "consumer_financing",
            "quickbooks",
            "two_way_texting",
            "call_tracking",
            "client_portal",
            "paid_ads",
            "google_reviews",
            "email_marketing",
            "referral_program",
            "inventory",
            "documents",
            "reports",
            "custom_dashboards",
            "ai_receptionist",
            "map_view"
      ],
      settings: {
        products: ["crm"],
        siteUrl: 'https://claflin-construction.com',
        cmsUrl: '',
        generatedBy: 'Twomiah Build Factory',
        generatedAt: new Date().toISOString(),
      },
    },
  });

  // Create admin user
  const passwordHash = await bcrypt.hash('3KDJWesd!', 12);
  
  await prisma.user.create({
    data: {
      email: 'info@claflinconstruction.net',
      passwordHash,
      firstName: 'Admin',
      lastName: 'User',
      role: 'owner',
      companyId: company.id,
    },
  });

  console.log('✓ CRM setup complete!');
  console.log('');
  console.log('Login credentials:');
  console.log('  Email: info@claflinconstruction.net');
  console.log('  Password: 3KDJWesd!');
  console.log('');
  console.log('Enabled features: 47 features');
}

main()
  .catch((e) => { console.error(e); process.exit(1); })
  .finally(async () => { await prisma.$disconnect(); });
